<?php
if (!defined('ABSPATH')) { exit; }

add_action('enqueue_block_assets', static function () {
    wp_enqueue_style('parzero-site', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
});

add_action('after_switch_theme', static function () {
    if (get_option('parzero_home_page_id')) { return; }
    $content = file_get_contents(get_theme_file_path('content/home.html'));
    if ($content === false || trim($content) === '') { return; }
    $page = wp_insert_post(array(
        'post_title' => 'Home',
        'post_type' => 'page',
        'post_status' => 'publish',
        'post_content' => $content,
    ), true);
    if (is_wp_error($page) || !$page) { return; }
    update_option('parzero_home_page_id', $page);
    if (!get_option('page_on_front')) {
        update_option('page_on_front', $page);
        update_option('show_on_front', 'page');
    }
});
