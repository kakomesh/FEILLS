<?php
function parzero_import_pages($root) {
    $manifest = json_decode(file_get_contents($root . '/pages.json'), true, 32, JSON_THROW_ON_ERROR);
    $pages = $manifest['pages'];
    $ids = array();
    foreach ($pages as $page) {
        $slug = $page['slug'];
        if (!preg_match('/^[a-z0-9-]+$/D', $slug)) { throw new RuntimeException('Invalid page slug'); }
        $content = file_get_contents($root . '/content/' . $slug . '.html');
        if ($content === false) { throw new RuntimeException("Missing source for $slug"); }
        $stack = parse_blocks($content);
        $named = false;
        while ($stack) {
            $block = array_pop($stack);
            if (!empty($block['blockName'])) { $named = true; }
            if ($block['blockName'] === 'core/html') { throw new RuntimeException("Custom HTML block in $slug"); }
            array_push($stack, ...$block['innerBlocks']);
        }
        if (!$named) { throw new RuntimeException("No serialized blocks for $slug"); }
        $existing = get_page_by_path($slug, OBJECT, 'page');
        $hash = hash('sha256', $content);
        if ($existing) {
            $ids[$slug] = $existing->ID;
            $prior = get_post_meta($existing->ID, '_parzero_source_hash', true);
            if ($prior !== hash('sha256', $existing->post_content)) {
                if (defined('WP_CLI') && WP_CLI) { echo "Preserved editor content for $slug\n"; }
                continue;
            }
        }
        $data = array(
            'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug,
            'post_title' => $page['title'], 'post_content' => $content,
            'page_template' => $page['template'] ?? 'default',
        );
        if ($existing) { $data['ID'] = $existing->ID; }
        $id = wp_insert_post(wp_slash($data), true);
        if (is_wp_error($id) || !$id) { throw new RuntimeException("Could not provision $slug"); }
        update_post_meta($id, '_parzero_source_hash', hash('sha256', get_post_field('post_content', $id, 'raw')));
        $ids[$slug] = $id;
    }
    foreach (($manifest['remove'] ?? array()) as $slug) {
        if (isset($ids[$slug])) { continue; }
        $existing = get_page_by_path($slug, OBJECT, 'page');
        if ($existing && get_post_meta($existing->ID, '_parzero_source_hash', true) === hash('sha256', $existing->post_content)) {
            wp_trash_post($existing->ID);
        }
    }
    $target = $ids[$manifest['frontPage']] ?? 0;
    $prior = (int) get_option('_parzero_front_page', 0);
    $actual = (int) get_option('page_on_front');
    if ($target && (!$actual || $actual === $prior)) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $target);
        update_option('_parzero_front_page', $target);
    }
}
if (defined('WP_CLI') && WP_CLI && __FILE__ === '/opt/parzero/provision.php') {
    parzero_import_pages(WP_CONTENT_DIR . '/themes/parzero-theme');
}

